from lib.Slave import Slave


def main():
    while True:
        print("[+] Starting Slave")
        slave = Slave()
        slave.Start_session()
        print("[-] Stopping Slave")


if __name__ == '__main__':
    main()
