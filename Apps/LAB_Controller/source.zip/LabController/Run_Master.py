import os
import socket

from LabController.lib.Master import Master


def runOnce():
    with open('./lib/DataBase/GetIP.txt') as f:
        lines = f.read().splitlines()
    if lines[0] == 'True':
        return True
    else:
        os.system('pip install -r ../LabController/lib/DataBase/install.txt')
        _ = input('Enter IP or press Enter (No Input to get default) : ')
        if _ == '':
            _ = socket.gethostbyname(socket.gethostname())
        f = open('/lib/DataBase/IpOfMaster.txt', 'w')
        f.write(_)
        f = open('./lib/DataBase/GetIP.txt', 'w')
        f.write('True')
    return True


def main():
    runOnce()
    master = Master()
    print("[+] Starting server")
    master.run_server()
    print("[-] Stopping server")


if __name__ == '__main__':
    main()
