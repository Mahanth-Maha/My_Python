
import socket
import win32api
import win32con

from LabController.lib import Shutdown


class Slave:
    def __init__(self):
        self.s = socket.socket()
        # host = "10.66.17.222"
        self.host = '127.0.0.1'
        self.port = 44095
        # host = input('enter IP of master : ')
        # port = input('enter port of master : ')
        self.OK = False
        self.conn()

    def conn(self):
        try:
            self.s.connect((self.host, self.port))
            self.OK = True
        except ConnectionRefusedError:
            print('Retrying')

    def Start_session(self):
        if self.OK:
            while True:
                try:
                    k = self.s.recv(10240)
                    k = k.decode()
                    cmd = k.split(' ')
                    if len(cmd) != 0:
                        if cmd[0] == 'PopUp':
                            st = ''
                            for i in cmd[1:]:
                                st += ' ' + i
                            win32api.MessageBox(0, str(st), "Sir Says", win32con.MB_OK)
                        if cmd[0] == 'ShutDown':
                            shut = Shutdown.ShutdownAuto()
                            reply = shut.DoesUserResponded()
                            if reply == 6:
                                print('shutdown successful')
                                self.s.close()
                                # os.system("shutdown /s /t 1")
                                break
                            else:
                                print("Sending To Master !")
                        if cmd[0] == 'Closed':
                            print("Server Closed Connection ")
                            self.s.close()
                except ConnectionResetError:
                    print('retry due to reset')
                    break


if __name__ == '__main__':
    while True:
        slave = Slave()
        slave.Start_session()
