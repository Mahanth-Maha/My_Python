import win32api, win32con
import time
import sys
from threading import Thread
from pynput.keyboard import Key, Controller


class ShutdownAuto:
    def __init__(self):
        self.keyboard = Controller()
        self.m1 = 6
        self.TIMERTOUSER = 5

    def enter_explicit(self):
        self.keyboard.press(Key.enter)
        self.keyboard.release(Key.enter)

    def ask_user(self):
        self.m1 = win32api.MessageBox(0, "Press No to stop", "SHUTDOWN AUTO", win32con.MB_YESNO)

    def enter_by_bot(self):
        time.sleep(self.TIMERTOUSER)
        if self.m1 not in (6, 7):
            self.enter_explicit()

    def DoesUserResponded(self):
        threads_list = []
        try:
            for fun in [self.enter_by_bot, self.ask_user]:
                th = Thread(target=fun)
                th.start()
                threads_list.append(th)
                # time.sleep(5)
        except KeyboardInterrupt:
            sys.exit(0)
        finally:
            [t_s.join() for t_s in threads_list]
            # if self.m1 == 1:
            #     return False
            # return True
            return self.m1


if __name__ == "__main__":
    shut = ShutdownAuto()
    k = shut.DoesUserResponded()
    print(k)
